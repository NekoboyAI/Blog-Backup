---
layout: post
title: Antelitteram
author: mfp19
---

Tags: [h](#h)

We had a [problem](http://mfp19.github.io/2015/08/24/Integrity.html), we have a [solution](http://mfp19.github.io/2015/12/15/Solution.html), we marched to [enforce human rights for all](http://mfp19.github.io/2015/12/17/Constitution.html), we [fixed finance](http://mfp19.github.io/2015/12/20/Timeless.html), and we imagined (again) [how the world could be](http://mfp19.github.io/2015/12/25/Aethernum.html), then we [figured out why is not](http://mfp19.github.io/2015/12/26/Profile.html) and [where to find money to make it](http://mfp19.github.io/2015/12/27/PastaCiccia.html). Finally, some [relax](http://mfp19.github.io/2015/12/28/Checklist.html). 

Awesome. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/9Q7Vr3yQYWQ">Led Zeppelin - Stairway to Heaven Live (HD)</iframe>

But I understand that all that crap is verbose and a bit ambigous 

> "disambiguate something to show clearly the difference between two or more words, phrases, etc. which are similar in meaning"
> 
> ([an Oxford dictionary](http://www.oxforddictionaries.com/definition/learner/disambiguate))

So let's clean up a bit this fairy tale. 

# <a name="h"></a>Beware the "h"! 

> Ante litteram := Before the term existed; before the term was coined; used after a term applied anachronistically. 
> 
> (Wikiquote)

In italian the "h" is mute; teachers at kindergarden teach: no sound, no onion smell flowing out of our mouths, no mosquitos comin'inna. 

But "h" is not mute everywhere! Shame on me, I realised this for the very first time at 34 years old: I welcomed with "Hi horny!", my female friends, for a few months - some of those walking away disgusted - before a british girl figured out that I was truly convinced to be saying "Hi honey!". If you consider the UN hate speech crap, and Google Translate translating 'harassment' in swedish with "lesser rape" - yes, RAPE - you could end up in jail because of your education. Natural born h-raper: damned teachers! Don't get me wrong, I appreciate good education but: RAPE!? 

<iframe width="560" height="315" src="https://www.youtube.com/embed/CJh59vZ8ccc">Forrest Gump - "Life is like a box of chocolate"</iframe>

Look at this one 

> girlfriend: "why do you call her hairy pussy? BEHAVE!" (slap)
> 
> boyfriend: "WTF, again! I swear: I don't know how her pussy look like! I'd lik..even didn't know about that word in your language! Do you really have a word for that too? Cool" 
> 
> (a true story)

This and many other ... ehm ... cultural shocks: slaps, knocks, and a wide variety of other unpleasant results just because of the damned "h"! And because of this, I have a bunch of h-biqous words to disambiguate. 

